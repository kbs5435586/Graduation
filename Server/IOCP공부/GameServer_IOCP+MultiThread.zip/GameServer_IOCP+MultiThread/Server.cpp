#include <iostream>
#include <WS2tcpip.h>
#include <MSWSock.h>
#include <thread>
#include <mutex>
#include <vector>
#include "protocol.h"

using namespace std;
#pragma comment(lib, "Ws2_32.lib")
#pragma comment(lib, "MSWSock.lib")
constexpr int MAX_BUFFER = 4096;


constexpr char OP_MODE_RECV = 0;
constexpr char OP_MODE_SEND = 1;
constexpr char OP_MODE_ACCEPT = 2;

constexpr int  KEY_SERVER = 1000000;

struct OVER_EX {
    WSAOVERLAPPED wsa_over;
    char   op_mode;
    WSABUF   wsa_buf;
    unsigned char iocp_buf[MAX_BUFFER];
};

struct client_info {
    mutex c_lock;
    char name[MAX_ID_LEN];
    short x, y;

    bool in_use;
    SOCKET   m_sock;
    OVER_EX   m_recv_over;
    unsigned char* m_packet_start;
    unsigned char* m_recv_start;
};

mutex id_lock;
client_info g_clients[MAX_USER];
HANDLE      h_iocp;

SOCKET g_lSocket;
OVER_EX g_accept_over;

void error_display(const char* msg, int err_no)
{
    WCHAR* lpMsgBuf;
    FormatMessage(
        FORMAT_MESSAGE_ALLOCATE_BUFFER |
        FORMAT_MESSAGE_FROM_SYSTEM,
        NULL, err_no,
        MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
        (LPTSTR)&lpMsgBuf, 0, NULL);
    std::cout << msg;
    std::wcout << L"���� " << lpMsgBuf << std::endl;
    while (true);
    LocalFree(lpMsgBuf);
}

void send_packet(int id, void* p)
{
    unsigned char* packet = reinterpret_cast<unsigned char*>(p);
    OVER_EX* send_over = new OVER_EX;
    memcpy(send_over->iocp_buf, packet, packet[0]);
    send_over->op_mode = OP_MODE_SEND;
    send_over->wsa_buf.buf = reinterpret_cast<CHAR*>(send_over->iocp_buf);
    send_over->wsa_buf.len = packet[0];
    ZeroMemory(&send_over->wsa_over, sizeof(send_over->wsa_over));
    g_clients[id].c_lock.lock();
    if (true == g_clients[id].in_use)
        WSASend(g_clients[id].m_sock, &send_over->wsa_buf, 1, NULL, 0, &send_over->wsa_over, NULL);
    g_clients[id].c_lock.unlock();
}

void send_login_ok(int id)
{
    sc_packet_login_ok p;
    p.exp = 0;
    p.hp = 100;
    p.id = id;
    p.level = 1;
    p.size = sizeof(p);
    p.type = SC_PACKET_LOGIN_OK;
    p.x = g_clients[id].x;
    p.y = g_clients[id].y;
    send_packet(id, &p);
}

void send_move_packet(int to_client, int id)
{
    sc_packet_move p;
    p.id = id;
    p.size = sizeof(p);
    p.type = SC_PACKET_MOVE;
    p.x = g_clients[id].x;
    p.y = g_clients[id].y;
    send_packet(to_client, &p);
}

void send_enter_packet(int to_client, int new_id)
{
    sc_packet_enter p;
    p.id = new_id;
    p.size = sizeof(p);
    p.type = SC_PACKET_ENTER;
    p.x = g_clients[new_id].x;
    p.y = g_clients[new_id].y;
    g_clients[new_id].c_lock.lock();
    strcpy_s(p.name, g_clients[new_id].name);
    g_clients[new_id].c_lock.unlock();
    p.o_type = 0;
    send_packet(to_client, &p);
}

void send_leave_packet(int to_client, int old_id)
{
    sc_packet_leave p;
    p.id = old_id;
    p.size = sizeof(p);
    p.type = SC_PACKET_LEAVE;
    send_packet(to_client, &p);
}

void process_move(int id, char dir)
{
    short y = g_clients[id].y;
    short x = g_clients[id].x;
    switch (dir) {
    case MV_UP:
        if (y > 0)
            y--;
        break;
    case MV_DOWN:
        if (y < WORLD_HEIGHT - 1)
            y++;
        break;
    case MV_LEFT:
        if (x > 0)
            x--;
        break;
    case MV_RIGHT:
        if (x < WORLD_WIDTH - 1)
            x++;
        break;
    default:
        cout << "Unknown Direction in CS_MOVE packet.\n";
        while (true);
    }
    g_clients[id].x = x;
    g_clients[id].y = y;

    for (int i = 0; i < MAX_USER; ++i)
    {
        if (true == g_clients[i].in_use)
        {
            send_move_packet(i, id);
        }
    }
}

void process_packet(int id)
{
    char p_type = g_clients[id].m_packet_start[1]; // ��Ŷ�� ��������
    // p_type �� ��Ŷ Ÿ��
    switch (p_type)
    {
    case CS_LOGIN:
    {
        cs_packet_login* p = reinterpret_cast<cs_packet_login*>(g_clients[id].m_packet_start);
        g_clients[id].c_lock.lock();
        strcpy_s(g_clients[id].name, p->name);
        g_clients[id].c_lock.unlock();
        send_login_ok(id);
        for (int i = 0; i < MAX_USER; ++i)
        {
            if (true == g_clients[i].in_use) {
                if (id != i) {
                    send_enter_packet(i, id);
                    send_enter_packet(id, i);
                }
            }
        }
    }
    break;
    case CS_MOVE:
    {
        cs_packet_move* p1 = reinterpret_cast<cs_packet_move*>(g_clients[id].m_packet_start);
        process_move(id, p1->direction);
    }
    break;
    default:
        cout << "Unknown Packet Type [" << p_type << "] from Client [" << id << "]\n";
        while (true);
    }
}

constexpr int MIN_BUFF_SIZE = 1024;

void process_recv(int id, DWORD iosize)
{
    unsigned char p_size = g_clients[id].m_packet_start[0];
    unsigned char* next_recv_ptr = g_clients[id].m_recv_start + iosize;
    while (p_size <= next_recv_ptr - g_clients[id].m_packet_start) {
        process_packet(id);
        g_clients[id].m_packet_start += p_size;
        if (g_clients[id].m_packet_start < next_recv_ptr)
            p_size = g_clients[id].m_packet_start[0];
        else break;
    }

    long long left_data = next_recv_ptr - g_clients[id].m_packet_start;

    if ((MAX_BUFFER - (next_recv_ptr - g_clients[id].m_recv_over.iocp_buf))
        < MIN_BUFF_SIZE) {
        memcpy(g_clients[id].m_recv_over.iocp_buf,
            g_clients[id].m_packet_start, left_data);
        g_clients[id].m_packet_start = g_clients[id].m_recv_over.iocp_buf;
        next_recv_ptr = g_clients[id].m_packet_start + left_data;
    }
    DWORD recv_flag = 0;
    g_clients[id].m_recv_start = next_recv_ptr;
    g_clients[id].m_recv_over.wsa_buf.buf = reinterpret_cast<CHAR*>(next_recv_ptr);
    g_clients[id].m_recv_over.wsa_buf.len = MAX_BUFFER -
        static_cast<int>(next_recv_ptr - g_clients[id].m_recv_over.iocp_buf);

    g_clients[id].c_lock.lock();
    if (true == g_clients[id].in_use) {
        WSARecv(g_clients[id].m_sock, &g_clients[id].m_recv_over.wsa_buf,
            1, NULL, &recv_flag, &g_clients[id].m_recv_over.wsa_over, NULL);
    }
    g_clients[id].c_lock.unlock();
}

void add_new_client(SOCKET ns)
{
    int i;
    id_lock.lock();
    for (i = 0; i < MAX_USER; ++i)
        if (false == g_clients[i].in_use) break;
    id_lock.unlock();

    if (MAX_USER == i)
    {
        cout << "Max user limit exceeded.\n";
        closesocket(ns);
    }
    else
    {
        cout << "New Client [" << i << "] Accepted" << endl;
        g_clients[i].c_lock.lock();
        g_clients[i].in_use = true;
        g_clients[i].m_sock = ns;
        g_clients[i].name[0] = 0;
        g_clients[i].c_lock.unlock();

        g_clients[i].m_packet_start = g_clients[i].m_recv_over.iocp_buf;
        g_clients[i].m_recv_over.op_mode = OP_MODE_RECV;
        g_clients[i].m_recv_over.wsa_buf.buf = reinterpret_cast<CHAR*>(g_clients[i].m_recv_over.iocp_buf);
        g_clients[i].m_recv_over.wsa_buf.len = sizeof(g_clients[i].m_recv_over.iocp_buf);
        ZeroMemory(&g_clients[i].m_recv_over.wsa_over, sizeof(g_clients[i].m_recv_over.wsa_over));
        g_clients[i].m_recv_start = g_clients[i].m_recv_over.iocp_buf;
        g_clients[i].x = rand() % WORLD_WIDTH;
        g_clients[i].y = rand() % WORLD_HEIGHT;
        CreateIoCompletionPort(reinterpret_cast<HANDLE>(ns), h_iocp, i, 0);

        DWORD flags = 0;
        int ret = 0;
        g_clients[i].c_lock.lock();
        if (true == g_clients[i].in_use) {
            ret = WSARecv(g_clients[i].m_sock, &g_clients[i].m_recv_over.wsa_buf, 1, NULL,
                &flags, &g_clients[i].m_recv_over.wsa_over, NULL);
        }
        g_clients[i].c_lock.unlock();
        if (SOCKET_ERROR == ret) {
            int err_no = WSAGetLastError();
            if (ERROR_IO_PENDING != err_no)
                error_display("WSARecv : ", err_no);
        }
    }
    SOCKET cSocket = WSASocket(AF_INET, SOCK_STREAM, 0, NULL, 0, WSA_FLAG_OVERLAPPED);
    g_accept_over.op_mode = OP_MODE_ACCEPT;
    g_accept_over.wsa_buf.len = static_cast<ULONG>(cSocket);
    ZeroMemory(&g_accept_over.wsa_over, 0, sizeof(g_accept_over.wsa_over));
    AcceptEx(g_lSocket, cSocket, g_accept_over.iocp_buf, 0, 32, 32, NULL, &g_accept_over.wsa_over);
}

void disconnect_client(int id)
{
    for (int i = 0; i < MAX_USER; ++i)
    {
        if (true == g_clients[i].in_use)
        {
            if (id != i)
            {
                send_leave_packet(i, id);
            }
        }
    }
    g_clients[id].c_lock.lock();
    g_clients[id].in_use = false;
    closesocket(g_clients[id].m_sock);
    g_clients[id].m_sock = 0;
    g_clients[id].c_lock.unlock();
}

void worker_thread()
{
    // �ݺ�
    //      - �� �����带 IOCP thread pool�� ���   => GQCS
    //      - iocp�� ó���� �±� I/O �Ϸ� �����͸� ������  => GQCS
    //      - ���� I/O�Ϸ� �����͸� ó��

    while (true) {
        DWORD io_size;
        int key;
        ULONG_PTR iocp_key;
        WSAOVERLAPPED* lpover;
        // �����ϸ� True, �����ϸ� False
        int ret = GetQueuedCompletionStatus(h_iocp, &io_size, &iocp_key, &lpover, INFINITE);
        key = static_cast<int>(iocp_key);
        cout << "Completion Detected" << endl;
        if (FALSE == ret) {
            error_display("GQCS ERROR : ", WSAGetLastError());
        }

        OVER_EX* over_ex = reinterpret_cast<OVER_EX*>(lpover);
        switch (over_ex->op_mode) {
        case OP_MODE_ACCEPT:
            add_new_client(static_cast<SOCKET>(over_ex->wsa_buf.len));
            break;
        case OP_MODE_RECV:
            if (0 == io_size)
            {
                disconnect_client(key);
            }
            else
            {
                cout << "Packet from Client [" << key << "]" << endl;
                process_recv(key, io_size);
            }
            break;
        case OP_MODE_SEND:
            delete over_ex; // send�Ҷ� ����� ������ ��ȯ, ������ �ؾ���
            break;
        }
    }
}

int main()
{
    std::wcout.imbue(std::locale("korean"));

    for (auto& cl : g_clients)
        cl.in_use = false;

    WSADATA WSAData;
    WSAStartup(MAKEWORD(2, 0), &WSAData);
    h_iocp = CreateIoCompletionPort(INVALID_HANDLE_VALUE, NULL, NULL, 0);
    g_lSocket = WSASocket(AF_INET, SOCK_STREAM, 0, NULL, 0, WSA_FLAG_OVERLAPPED);
    CreateIoCompletionPort((HANDLE)g_lSocket, h_iocp, KEY_SERVER, 0);

    SOCKADDR_IN serverAddr;
    memset(&serverAddr, 0, sizeof(SOCKADDR_IN));
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(SERVER_PORT);
    serverAddr.sin_addr.s_addr = INADDR_ANY;
    ::bind(g_lSocket, (sockaddr*)&serverAddr, sizeof(serverAddr));
    listen(g_lSocket, 5);

    SOCKET cSocket = WSASocket(AF_INET, SOCK_STREAM, 0, NULL, 0, WSA_FLAG_OVERLAPPED);
    g_accept_over.op_mode = OP_MODE_ACCEPT;
    g_accept_over.wsa_buf.len = static_cast<ULONG>(cSocket);
    ZeroMemory(&g_accept_over.wsa_over, 0, sizeof(g_accept_over.wsa_over));
    AcceptEx(g_lSocket, cSocket, g_accept_over.iocp_buf, 0, 32, 32, NULL, &g_accept_over.wsa_over);

    vector<thread> worker_threads;
    for (int i = 0; i < 6; ++i)
    {
        worker_threads.emplace_back(worker_thread);
    }
    for (auto& th : worker_threads)
        th.join();

    closesocket(g_lSocket);
    WSACleanup();
}