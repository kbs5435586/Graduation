#pragma once
#include "Base.h"
class CFbxLoader :
    public CBase
{
};

