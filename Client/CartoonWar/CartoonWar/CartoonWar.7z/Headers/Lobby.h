#pragma once
#include "Scene.h"
class CLobby :
    public CScene
{
};

