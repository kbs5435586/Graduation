#pragma once
#include "GameObject.h"
class CBarrel01 :
    public CGameObject
{
};

