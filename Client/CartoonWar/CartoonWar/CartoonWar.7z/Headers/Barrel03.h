#pragma once
#include "GameObject.h"
class CBarrel03 :
    public CGameObject
{
};

