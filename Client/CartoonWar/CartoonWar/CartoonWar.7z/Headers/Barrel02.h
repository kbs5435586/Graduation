#pragma once
#include "GameObject.h"
class CBarrel02 :
    public CGameObject
{
};

