#include "framework.h"
#include "Buffer_Cylinder.h"
#define _USE_MATH_DEFINES
#include <math.h>


CBuffer_Cylinder::CBuffer_Cylinder()
	: CVIBuffer()
{
}

CBuffer_Cylinder::CBuffer_Cylinder(const CBuffer_Cylinder& rhs)
	: CVIBuffer(rhs)
{
}

HRESULT CBuffer_Cylinder::Ready_VIBuffer()
{
	topRadius = 1.f;
	botRadius = 1.f;

	height = 1.f;

	sliceCount = 30;
	stackCount = 1;

	vector<VTXTEXCUBE> vecVertices;

	float stackHeight = height / (float)stackCount;

	float radiusStep = (topRadius - botRadius) / (float)stackCount;

	_uint ringCount = stackCount + 1;

	for (_uint i = 0; i < ringCount; ++i)
	{
		float y = -0.5f * height + i * stackHeight;
		float r = botRadius + i * radiusStep;

		float phi = 2.f *  M_PI / (float)sliceCount;


		for (_uint k = 0; k <= sliceCount; ++k)
		{
			float x = r * cosf(k * phi);
			float z = r * sinf(k * phi);

			VTXTEXCUBE vertex;
			vertex.vPosition = _vec3(x, y, z);
			vertex.vTex = vertex.vPosition;
			//_vec3 tangent = _vec3(-z, 0.f, x);
			//
			//float dr = botRadius - topRadius;
			//_vec3 biTangent = _vec3(dr * x, -height, dr * z);
			//
			//vertex.vTex = Vector3_::CrossProduct(tangent, biTangent);
			//vertex.vTex = Vector3_::Normalize(vertex.vTex);

			vecVertices.push_back(vertex);
		}
	}

	vector<_uint> indices;
	_uint ringVertexCount = sliceCount + 1;

	for (_uint y = 0; y < stackCount; ++y)
	{
		for (_uint x = 0; x < sliceCount; ++x)
		{
			indices.push_back(y * ringVertexCount + x);
			indices.push_back((y+1) * ringVertexCount + x);
			indices.push_back((y+1) * ringVertexCount + (x+1));

			indices.push_back(y * ringVertexCount + x);
			indices.push_back((y+1) * ringVertexCount + x + 1);
			indices.push_back(y * ringVertexCount + x + 1);
		}
	}

	//BuildTopCap(vecVertices, indices);
	//BuildBotCap(vecVertices, indices);

	//{
	//	float y = 0.5f * height;

	//	float phi = 2.f * M_PI / (float)sliceCount;

	//	for (_uint i = 0; i <= sliceCount; ++i)
	//	{
	//		float x = topRadius * cosf(i * phi);
	//		float z = topRadius * sinf(i * phi);

	//		float u = x / height + 0.5f;
	//		float v = z / height + 0.5f;

	//		vecVertices.push_back(VTXTEXCUBE(XMFLOAT3(x, y, z), XMFLOAT3(x, y, z)));
	//		//vertices.push_back(VTXTEXCUBE(x, y, z, 0, -1, 0));
	//	}
	//	vecVertices.push_back(VTXTEXCUBE(XMFLOAT3(0, y, 0), XMFLOAT3(0, y, 0)));
	//	//vertices.push_back(VTXTEXCUBE(0, y, 0, 0, -1, 0));


	//	_uint baseIndex = vecVertices.size() - sliceCount - 2;

	//	_uint centerIndex = vecVertices.size() - 1;

	//	for (_uint i = 0; i < sliceCount; ++i)
	//	{
	//		indices.push_back(centerIndex);
	//		indices.push_back(baseIndex + i + 1);
	//		indices.push_back(baseIndex + i);
	//	}
	//}

	//{
	//	float y = 0.5f * height;

	//	float phi = 2.f * M_PI / (float)sliceCount;

	//	for (_uint i = 0; i <= sliceCount; ++i)
	//	{
	//		float x = topRadius * cosf(i * phi);
	//		float z = topRadius * sinf(i * phi);

	//		float u = x / height + 0.5f;
	//		float v = z / height + 0.5f;

	//		vecVertices.push_back(VTXTEXCUBE(XMFLOAT3(x, y, z), XMFLOAT3(x, y, z)));
	//		//vertices.push_back(VTXTEXCUBE(x, y, z, 0, 1, 0));
	//	}
	//	vecVertices.push_back(VTXTEXCUBE(XMFLOAT3(0, y, 0), XMFLOAT3(0, y, 0)));
	//	//vertices.push_back(VTXTEXCUBE(0, y, 0, 0, 1, 0));


	//	_uint baseIndex = vecVertices.size() - sliceCount - 2;

	//	_uint centerIndex = vecVertices.size() - 1;

	//	for (_uint i = 0; i < sliceCount; ++i)
	//	{
	//		indices.push_back(centerIndex);
	//		indices.push_back(baseIndex + i + 1);
	//		indices.push_back(baseIndex + i);
	//	}
	//}
	
	

	_uint aaa = vecVertices.size();

	//���� ����
	m_iNumVertices = aaa;

	float rad = 1.f;
	//�� ���� ������ ũ��?
	m_iStride = sizeof(VTXTEXCUBE);


	_uint bbb = indices.size();
	//�ε���
	//�ð����
	m_iNumIndices = bbb;
	



	D3D12_HEAP_PROPERTIES tHeap_Pro_Default = CD3DX12_HEAP_PROPERTIES(D3D12_HEAP_TYPE_DEFAULT);
	D3D12_HEAP_PROPERTIES tHeap_Pro_Upload = CD3DX12_HEAP_PROPERTIES(D3D12_HEAP_TYPE_UPLOAD);

	CDevice::GetInstance()->Open();
	{
		//�������� ũ�� * �ε��� ���� ������ŭ �� 
		D3D12_RESOURCE_DESC		tResource_Desc = CD3DX12_RESOURCE_DESC::Buffer(m_iStride * m_iNumVertices);

		if (FAILED(CDevice::GetInstance()->GetDevice()->CreateCommittedResource(&tHeap_Pro_Default, D3D12_HEAP_FLAG_NONE,
			&tResource_Desc, D3D12_RESOURCE_STATE_COPY_DEST, nullptr, IID_PPV_ARGS(&m_pVertexBuffer))))
			return E_FAIL;
		m_pVertexBuffer->SetName(L"VertexBuffer");

		if (FAILED(CDevice::GetInstance()->GetDevice()->CreateCommittedResource(&tHeap_Pro_Upload, D3D12_HEAP_FLAG_NONE,
			&tResource_Desc, D3D12_RESOURCE_STATE_GENERIC_READ, nullptr, IID_PPV_ARGS(&m_pVertexUploadBuffer))))
			return E_FAIL;
		m_pVertexUploadBuffer->SetName(L"Upload VertexBuffer");



		//���� �������� ���ο� ���𰡸� ������
		D3D12_SUBRESOURCE_DATA vertexData = {};
		vertexData.pData = (void*)(vecVertices.data());
		//vector�� ���� .data() �Լ��� ���� ���ο��� ���Ҹ� �����ϴ� �迭�� ���� �����͸� ��ȯ�Ѵ�.
		vertexData.RowPitch = m_iStride * m_iNumIndices;
		vertexData.SlicePitch = m_iStride * m_iNumIndices;
		//���� �ΰ��� ���� ��� LONG_PTR�̶�� ������ ����Ǿ��ִ�. PTR�̶�� �̸��� ���� ��ŭ �ּҸ� �����ϴ� ���� �ϰ��̴�?
		//�ٵ� �� ���� ũ��� �ε��� ������ ���߳� �װ͵� �� ��?

		D3D12_RESOURCE_BARRIER	tResource_Barrier = CD3DX12_RESOURCE_BARRIER::Transition(m_pVertexBuffer.Get(), D3D12_RESOURCE_STATE_COPY_DEST, D3D12_RESOURCE_STATE_VERTEX_AND_CONSTANT_BUFFER);
		UpdateSubresources(CDevice::GetInstance()->GetCmdLst().Get(), m_pVertexBuffer.Get(), m_pVertexUploadBuffer.Get(), 0, 0, 1, &vertexData);
		CDevice::GetInstance()->GetCmdLst()->ResourceBarrier(1, &tResource_Barrier);
	}
	{
		D3D12_RESOURCE_DESC		tResource_Desc = CD3DX12_RESOURCE_DESC::Buffer(sizeof(_uint) * m_iNumIndices);


		if (FAILED(CDevice::GetInstance()->GetDevice()->CreateCommittedResource(&tHeap_Pro_Default, D3D12_HEAP_FLAG_NONE,
			&tResource_Desc, D3D12_RESOURCE_STATE_COPY_DEST, nullptr, IID_PPV_ARGS(&m_pIndexBuffer))))
			return E_FAIL;
		if (FAILED(CDevice::GetInstance()->GetDevice()->CreateCommittedResource(&tHeap_Pro_Upload, D3D12_HEAP_FLAG_NONE,
			&tResource_Desc, D3D12_RESOURCE_STATE_GENERIC_READ, nullptr, IID_PPV_ARGS(&m_pIndexUploadBuffer))))
			return E_FAIL;

		D3D12_SUBRESOURCE_DATA indexData = {};
		indexData.pData = (void*)(indices.data());
		indexData.RowPitch = sizeof(_uint) * m_iNumIndices;
		indexData.SlicePitch = sizeof(_uint) * m_iNumIndices;

		D3D12_RESOURCE_BARRIER	tResource_Barrier = CD3DX12_RESOURCE_BARRIER::Transition(m_pIndexBuffer.Get(), D3D12_RESOURCE_STATE_COPY_DEST, D3D12_RESOURCE_STATE_INDEX_BUFFER);
		UpdateSubresources(CDevice::GetInstance()->GetCmdLst().Get(), m_pIndexBuffer.Get(), m_pIndexUploadBuffer.Get(), 0, 0, 1, &indexData);
		CDevice::GetInstance()->GetCmdLst()->ResourceBarrier(1, &tResource_Barrier);
	}
	CDevice::GetInstance()->Close();


	m_tVertexBufferView.BufferLocation = m_pVertexBuffer->GetGPUVirtualAddress();
	m_tVertexBufferView.StrideInBytes = m_iStride;
	m_tVertexBufferView.SizeInBytes = m_iStride * m_iNumVertices;

	m_tIndexBufferView.BufferLocation = m_pIndexBuffer->GetGPUVirtualAddress();
	m_tIndexBufferView.Format = DXGI_FORMAT_R32_UINT;
	m_tIndexBufferView.SizeInBytes = sizeof(_uint) * m_iNumIndices;

	CDevice::GetInstance()->WaitForFenceEvent();

	return S_OK;
}

CBuffer_Cylinder* CBuffer_Cylinder::Create()
{
	CBuffer_Cylinder* pInstance = new CBuffer_Cylinder();

	if (FAILED(pInstance->Ready_VIBuffer()))
	{
		MessageBox(0, L"CBuffer_Cylinder Created Failed", L"System Error", MB_OK);
		Safe_Release(pInstance);
	}
	return pInstance;
}

CComponent* CBuffer_Cylinder::Clone_Component(void* pArg)
{
	return new CBuffer_Cylinder(*this);
}

void CBuffer_Cylinder::Free()
{
	CVIBuffer::Free();
}

void CBuffer_Cylinder::BuildTopCap(vector<VTXTEXCUBE>& vertices, vector<_uint>& indices)
{
	float y = 0.5f * height;

	float phi = 2.f * M_PI / (float)sliceCount;

	for (_uint i = 0; i <= sliceCount; ++i)
	{
		float x = topRadius * cosf(i * phi);
		float z = topRadius * sinf(i * phi);

		float u = x / height + 0.5f;
		float v = z / height + 0.5f;
		
		vertices.push_back(VTXTEXCUBE(XMFLOAT3(x, y, z), XMFLOAT3(x, y, z)));
		//vertices.push_back(VTXTEXCUBE(x, y, z, 0, 1, 0));
	}
	vertices.push_back(VTXTEXCUBE(XMFLOAT3(0, y, 0), XMFLOAT3(0, y, 0)));
	//vertices.push_back(VTXTEXCUBE(0, y, 0, 0, 1, 0));


	_uint baseIndex = vertices.size() - sliceCount - 2;

	_uint centerIndex = vertices.size() - 1;

	for (_uint i = 0; i < sliceCount; ++i)
	{
		indices.push_back(centerIndex);
		indices.push_back(baseIndex + i + 1);
		indices.push_back(baseIndex + i);
	}
}

void CBuffer_Cylinder::BuildBotCap(vector<VTXTEXCUBE>& vertices, vector<_uint>& indices)
{
	float y = 0.5f * height;

	float phi = 2.f * M_PI / (float)sliceCount;

	for (_uint i = 0; i <= sliceCount; ++i)
	{
		float x = topRadius * cosf(i * phi);
		float z = topRadius * sinf(i * phi);

		float u = x / height + 0.5f;
		float v = z / height + 0.5f;

		vertices.push_back(VTXTEXCUBE(XMFLOAT3(x, y, z), XMFLOAT3(x, y, z)));
		//vertices.push_back(VTXTEXCUBE(x, y, z, 0, -1, 0));
	}
	vertices.push_back(VTXTEXCUBE(XMFLOAT3(0, y, 0), XMFLOAT3(0, y, 0)));
	//vertices.push_back(VTXTEXCUBE(0, y, 0, 0, -1, 0));


	_uint baseIndex = vertices.size() - sliceCount - 2;

	_uint centerIndex = vertices.size() - 1;

	for (_uint i = 0; i < sliceCount; ++i)
	{
		indices.push_back(centerIndex);
		indices.push_back(baseIndex + i + 1);
		indices.push_back(baseIndex + i);
	}
}

